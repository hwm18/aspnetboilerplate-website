﻿define([],
    function() {
        return function() {
            var that = this;

            that.activate = function() {
                //...
            };
        };
    });