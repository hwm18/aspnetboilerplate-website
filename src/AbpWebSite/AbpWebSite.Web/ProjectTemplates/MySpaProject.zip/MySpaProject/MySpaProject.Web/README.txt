﻿This is an empty project template to start with ASP.NET Boilerplate.

* Configured and ready-to-use frameworks/libraries:
  - Server side
	- ASP.NET MVC
	- ASP.NET Web API
    - Castle Windsor
	- NHibernate & FluentNhibernate
	- FluentMigrator
	- AutoMapper
	- Log4Net
  - Client side
    - Twitter Bootstrap
	- Durandaljs & Transitions
	- jQuery & jQueryUI
	- jQuery plug-ins
	  - jQuery validation
	  - jTable (TODO: add with extension)
	  - toastr
	  - spin.js
    - Knockoutjs & Knockout.mapping
	- Requirejs
	- Modernizr
	- json2
 
See http://www.aspnetboilerplate.com