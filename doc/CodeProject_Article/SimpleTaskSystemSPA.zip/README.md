Simple Task System
=====================

This is a sample project developed using ASP.NET Boilerplate as a SPA.
