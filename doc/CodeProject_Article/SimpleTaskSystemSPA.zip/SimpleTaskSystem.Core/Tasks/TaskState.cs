﻿namespace SimpleTaskSystem.Tasks
{
    public enum TaskState : byte
    {
        Active = 1,
        Completed = 2
    }
}