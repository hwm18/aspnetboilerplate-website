﻿using Abp.Domain.Repositories;

namespace SimpleTaskSystem.People
{
    public interface IPersonRepository : IRepository<Person>
    {

    }
}
